
# unreleased

## Features

## Changes

## Bugfixes

## Other

## Packaging

# v0.3.1

- Update dependencies to fix crash on Wayland, see #47 and #48 (@cyrozap)

# v0.3.0

- Improved performance for the entropy computation, see #32 (@siedentop)

# v0.2.0

- Support for using `mmap`, allowing to view huge files while decreasing memory consumption to a minimum, see #21 and #24 (@toolCHAINZ)

# v0.1.2

- Update to new wgpu version, minor fixes

# v0.1.1

- Fix mouse drag speed in zoomed mode
- Only show divide buttons if remainder is zero

# v0.1.0

Initial release
