module completions {

  # A command-line utility for easily compressing and decompressing files and directories.
  export extern ouch [
    --yes(-y)                 # Skip [Y/n] questions, default to yes
    --no(-n)                  # Skip [Y/n] questions, default to no
    --accessible(-A)          # Activate accessibility mode, reducing visual noise
    --hidden(-H)              # Ignore hidden files
    --quiet(-q)               # Silence output
    --gitignore(-g)           # Ignore files matched by git's ignore files
    --format(-f): string      # Specify the format of the archive
    --password(-p): string    # Decompress or list with password
    --threads(-c): string     # Concurrent working threads
    --help(-h)                # Print help (see more with '--help')
    --version(-V)             # Print version
  ]

  # Compress one or more files into one output file
  export extern "ouch compress" [
    --level(-l): string       # Compression level, applied to all formats
    --fast                    # Fastest compression level possible, conflicts with --level and --slow
    --slow                    # Slowest (and best) compression level possible, conflicts with --level and --fast
    --follow-symlinks(-S)     # Read from target files instead of from symlinks (relevant for `tar` and `zip`)
    --yes(-y)                 # Skip [Y/n] questions, default to yes
    --no(-n)                  # Skip [Y/n] questions, default to no
    --accessible(-A)          # Activate accessibility mode, reducing visual noise
    --hidden(-H)              # Ignore hidden files
    --quiet(-q)               # Silence output
    --gitignore(-g)           # Ignore files matched by git's ignore files
    --format(-f): string      # Specify the format of the archive
    --password(-p): string    # Decompress or list with password
    --threads(-c): string     # Concurrent working threads
    --help(-h)                # Print help
    ...files: path            # Files to be compressed
    output: path              # The resulting file. Its extensions can be used to specify the compression formats
  ]

  # Decompresses one or more files, optionally into another folder
  export extern "ouch decompress" [
    --dir(-d): path           # Decompress inside OUTPUT_DIR instead of the basename-derived subdirectory
    --here                    # Extract directly into the current directory, like `tar -xf` and `unzip` do
    --remove(-r)              # Remove the source file after successful decompression
    --yes(-y)                 # Skip [Y/n] questions, default to yes
    --no(-n)                  # Skip [Y/n] questions, default to no
    --accessible(-A)          # Activate accessibility mode, reducing visual noise
    --hidden(-H)              # Ignore hidden files
    --quiet(-q)               # Silence output
    --gitignore(-g)           # Ignore files matched by git's ignore files
    --format(-f): string      # Specify the format of the archive
    --password(-p): string    # Decompress or list with password
    --threads(-c): string     # Concurrent working threads
    --help(-h)                # Print help
    ...files: path            # Files to be decompressed, or "-" for stdin
  ]

  # List contents of an archive
  export extern "ouch list" [
    --tree(-t)                # Show archive contents as a tree
    --yes(-y)                 # Skip [Y/n] questions, default to yes
    --no(-n)                  # Skip [Y/n] questions, default to no
    --accessible(-A)          # Activate accessibility mode, reducing visual noise
    --hidden(-H)              # Ignore hidden files
    --quiet(-q)               # Silence output
    --gitignore(-g)           # Ignore files matched by git's ignore files
    --format(-f): string      # Specify the format of the archive
    --password(-p): string    # Decompress or list with password
    --threads(-c): string     # Concurrent working threads
    --help(-h)                # Print help
    ...archives: path         # Archives whose contents should be listed
  ]

  # Print this message or the help of the given subcommand(s)
  export extern "ouch help" [
  ]

  # Compress one or more files into one output file
  export extern "ouch help compress" [
  ]

  # Decompresses one or more files, optionally into another folder
  export extern "ouch help decompress" [
  ]

  # List contents of an archive
  export extern "ouch help list" [
  ]

  # Print this message or the help of the given subcommand(s)
  export extern "ouch help help" [
  ]

}

export use completions *
