; inherits: rust
